# app/daily_review/models.py
from sqlalchemy import Column, Integer, String, ForeignKey, Date, Text
from sqlalchemy.orm import relationship
from app.common.database import Base

class DailyReviewState(Base):
    __tablename__ = 'daily_review_state'

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    date = Column(Date, nullable=False)
    energy_level = Column(Integer, nullable=False)
    happiness_level = Column(Integer, nullable=False)
    stress_level = Column(Integer, nullable=False)

class DailyReviewQuestions(Base):
    __tablename__ = 'daily_review_questions'

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    question_text = Column(String, nullable=False)

class DailyReviewAnswers(Base):
    __tablename__ = 'daily_review_answers'

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    date = Column(Date, nullable=False)
    question_id = Column(Integer, ForeignKey('daily_review_questions.id'), nullable=False)
    answer = Column(Text, nullable=True)

    question = relationship("DailyReviewQuestions", backref="answers")
