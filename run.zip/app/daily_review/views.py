# app/daily_review/views.py

from flask import Blueprint, request, render_template, redirect, url_for, flash
from datetime import date
from app.common.database import db_session
from app.daily_review.models import DailyReviewState, DailyReviewQuestions, DailyReviewAnswers
from app.common.models import User  # Модель пользователя
from flask_login import current_user, login_required
import os

# Создаем Blueprint для модуля анализа итогов дня
daily_review_bp = Blueprint('daily_review', __name__, template_folder='templates', static_folder='static')

# Роут для отображения и сохранения ежедневного отчета
@daily_review_bp.route('/daily-review/', methods=['GET', 'POST'])
@login_required
def get_daily_review():
    if request.method == 'POST':
        # Получение данных о состоянии пользователя
        energy_level = request.form.get('energy_level')
        happiness_level = request.form.get('happiness_level')
        stress_level = request.form.get('stress_level')
        
        # Извлечение вопросов, настроенных пользователем
        questions = DailyReviewQuestions.query.filter_by(user_id=current_user.id).all()
        answers = []

        # Сохранение ответов на вопросы
        for question in questions:
            answer_text = request.form.get(f'question_{question.id}')
            answers.append(DailyReviewAnswers(
                user_id=current_user.id,
                date=date.today(),
                question_id=question.id,
                answer=answer_text
            ))

        # Сохранение состояния пользователя
        review_state = DailyReviewState(
            user_id=current_user.id,
            date=date.today(),
            energy_level=int(energy_level),
            happiness_level=int(happiness_level),
            stress_level=int(stress_level)
        )

        # Добавление данных в сессию и фиксация изменений
        db_session.add(review_state)
        db_session.add_all(answers)
        db_session.commit()

        # Уведомление пользователя об успешном сохранении
        flash('Ваш дневной отчет успешно сохранен!', 'success')
        return redirect(url_for('daily_review.get_daily_review'))

    # Отображение формы для заполнения итогов дня
    questions = DailyReviewQuestions.query.filter_by(user_id=current_user.id).all()
    return render_template('daily_review/daily_review.html', questions=questions)

# Роут для настройки вопросов анализа
@daily_review_bp.route('/daily-review/customize/', methods=['GET', 'POST'])
@login_required
def customize_questions():
    if request.method == 'POST':
        # Получение новых текстов вопросов от пользователя
        question_texts = request.form.getlist('question_text')

        # Удаление старых вопросов пользователя
        DailyReviewQuestions.query.filter_by(user_id=current_user.id).delete()
        db_session.commit()

        # Создание новых вопросов на основе ввода пользователя
        new_questions = [
            DailyReviewQuestions(user_id=current_user.id, question_text=text)
            for text in question_texts if text.strip()
        ]

        # Добавление новых вопросов в базу данных
        db_session.add_all(new_questions)
        db_session.commit()

        # Уведомление пользователя об успешном обновлении списка
        flash('Список вопросов обновлен!', 'success')
        return redirect(url_for('daily_review.customize_questions'))

    # Отображение текущих вопросов для редактирования
    questions = DailyReviewQuestions.query.filter_by(user_id=current_user.id).all()
    return render_template('daily_review/customize_questions.html', questions=questions)
